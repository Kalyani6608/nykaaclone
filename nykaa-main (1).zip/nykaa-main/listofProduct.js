export default [
    {
        img : "https://images-static.nykaa.com/uploads/beb9fdeb-e96c-4c55-9138-ba487e5800aa.jpg?tr=w-200,cm-pad_resize",
        dis : "Up to 60% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/228bcd54-9099-4998-b4c3-777f77e592f6.jpg?tr=w-200,cm-pad_resize",
        dis : "Up to 50% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/5c50557a-cf1e-4500-8b0f-4b9321fce87e.jpg?tr=w-200,cm-pad_resize",
        dis : "Up to 70% off"
    },
    {
        img : "https://images-static.nykaa.com/uploads/6529686c-e1f9-4c33-98e8-d146493424db.jpg?tr=w-200,cm-pad_resize",
        dis : "Up to 50% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/6529686c-e1f9-4c33-98e8-d146493424db.jpg?tr=w-200,cm-pad_resize",
        dis : "Up to 70% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/9bf0f694-34b5-4960-9f0a-a6069445532d.jpg?tr=w-200,cm-pad_resize",
        dis : "Up to 70% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/1ee17084-9905-4921-ab01-9fb174d727ee.jpg?tr=w-200,cm-pad_resize",
        dis : "Up to 50% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/1ee17084-9905-4921-ab01-9fb174d727ee.jpg?tr=w-200,cm-pad_resize",
        dis : "Exciting offers",
    },
    {
        img : "https://images-static.nykaa.com/uploads/bc749a66-166c-464d-b1c6-71a64d5c64e1.jpg?tr=w-200,cm-pad_resize",
        dis : "Up to 50% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/fbc882ec-ed72-4d57-845b-4811136c85de.jpg?tr=w-200,cm-pad_resize",
        dis : "Up to 40% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/5474f425-87ad-4ba4-bede-3bdf693f64a3.jpg?tr=w-200,cm-pad_resize",
        dis : "Up to 40% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/f33c088a-b73d-4c13-9741-874e91e6a466.jpg?tr=w-200,cm-pad_resize",
        dis : "min 10% off",
    }
]
    