export default [
   "https://images-static.nykaa.com/uploads/44dd0587-e3ee-4181-87e3-aa623ad09ecc.gif?tr=w-240,cm-pad_resize",
   "https://images-static.nykaa.com/uploads/519b2575-0831-4b92-b530-caa43e2f77a0.gif?tr=w-240,cm-pad_resize",
   "https://images-static.nykaa.com/uploads/84967e87-d680-4f2c-a014-1c1ec93a2c15.gif?tr=w-240,cm-pad_resize",
   "https://images-static.nykaa.com/uploads/480adec8-0d45-4244-90b6-8b262cbd1e92.gif?tr=w-240,cm-pad_resize",
   "https://images-static.nykaa.com/uploads/480adec8-0d45-4244-90b6-8b262cbd1e92.gif?tr=w-240,cm-pad_resize",
   "https://images-static.nykaa.com/uploads/491bc884-2f46-4980-bbc3-5a1b814221c5.gif?tr=w-240,cm-pad_resize",
   "https://images-static.nykaa.com/uploads/491bc884-2f46-4980-bbc3-5a1b814221c5.gif?tr=w-240,cm-pad_resize",
   "https://images-static.nykaa.com/uploads/b165e0ed-b19a-41e0-bf76-9c12a2bdbd79.gif?tr=w-240,cm-pad_resize",
   "https://images-static.nykaa.com/uploads/3a838645-9dd0-450e-98a8-3d605eb81a8a.gif?tr=w-240,cm-pad_resize",
]