export default [
    {
        img : "https://images-static.nykaa.com/uploads/6e350752-7c60-431b-9474-add3b33395fa.jpg?tr=w-240,cm-pad_resize",
        dis : "Up to 65% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/b3b7dd8d-d8ef-450b-9213-d438db1c9fcc.jpg?tr=w-240,cm-pad_resize",
        dis : "Up to 50% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/2a249456-6efe-47d8-a1bb-9165ffca1f84.jpg?tr=w-240,cm-pad_resize",
        dis : "Up to 50% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/ce00fd6a-093b-4040-bfac-e587b8d140cd.jpg?tr=w-240,cm-pad_resize",
        dis : "Up to 80% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/3f1d8ebe-2829-439e-8f86-9db9ba4892bb.jpg?tr=w-240,cm-pad_resize",
        dis : "Up to 65% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/00c6e704-18a2-4bcf-8712-83d6244fba05.jpg?tr=w-240,cm-pad_resize",
        dis : "Up to 60% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/bb3760af-d016-45a4-b292-53f200a1232e.jpg?tr=w-240,cm-pad_resize",
        dis : "Up to 60% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/d5759d1c-294c-49ac-a668-90cf21592de4.jpg?tr=w-240,cm-pad_resize",
        dis : "Up to 50% off",
    },
    {
        img : "https://images-static.nykaa.com/uploads/1acb3b6c-b4d6-43ee-bd75-39d4e85a1365.jpg?tr=w-240,cm-pad_resize",
        dis : "Up to 70% off",
    },
]